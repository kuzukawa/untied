<?php

namespace ACFCustomDatabaseTables\Model\ACFFields;

class TimePickerACFField extends ACFFieldBase {

	const TYPE = 'time_picker';

}