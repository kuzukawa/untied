<?php

namespace ACFCustomDatabaseTables\Model\ACFFields;

class ButtonGroupACFField extends ACFFieldBase {

	const TYPE = 'button_group';

}