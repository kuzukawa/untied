<?php


namespace ACFCustomDatabaseTables\Contract;


interface ControllerInterface {

	public function init();

}