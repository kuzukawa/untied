<?php

namespace ACFCustomDatabaseTables\Model\ACFFields;

class UrlACFField extends ACFFieldBase {

	const TYPE = 'url';

}