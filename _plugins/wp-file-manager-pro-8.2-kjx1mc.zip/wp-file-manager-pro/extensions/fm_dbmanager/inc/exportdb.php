<?php if ( ! defined( 'ABSPATH' ) ) exit; 
global $wpdb;
$dbtables = $wpdb->get_col($wpdb->prepare("show tables", null)); 
if(isset($_POST['mk_export_db']) && $_POST['mk_export_db'] == 'Export Database' && wp_verify_nonce( $_POST['export_db_field'], 'mk_export_db_field' ))
{
  $this->exportDB($wpdb->dbhost, $wpdb->dbuser, $wpdb->dbpassword, $wpdb->dbname, $dbtables); 
}
?>
