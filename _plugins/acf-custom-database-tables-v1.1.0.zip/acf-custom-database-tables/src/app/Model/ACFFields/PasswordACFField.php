<?php

namespace ACFCustomDatabaseTables\Model\ACFFields;

class PasswordACFField extends ACFFieldBase {

	const TYPE = 'password';

}