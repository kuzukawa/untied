<?php

namespace ACFCustomDatabaseTables\Model\ACFFields;

class TextAreaACFField extends ACFFieldBase {

	const TYPE = 'textarea';

}