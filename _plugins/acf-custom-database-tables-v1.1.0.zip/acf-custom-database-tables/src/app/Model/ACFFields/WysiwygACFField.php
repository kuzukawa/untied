<?php

namespace ACFCustomDatabaseTables\Model\ACFFields;

class WysiwygACFField extends ACFFieldBase {

	const TYPE = 'wysiwyg';

}