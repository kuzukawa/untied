<div class="custom-text">
<?php 
if( get_theme_mod('rooten_toolbar_left_custom') ) {
	echo wp_kses_post(get_theme_mod('rooten_toolbar_left_custom'));
} ?>
</div>