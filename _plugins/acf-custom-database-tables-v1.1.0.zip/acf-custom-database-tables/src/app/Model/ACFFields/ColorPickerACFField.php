<?php

namespace ACFCustomDatabaseTables\Model\ACFFields;

class ColorPickerACFField extends ACFFieldBase {

	const TYPE = 'color_picker';

}