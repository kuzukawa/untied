jQuery(function()
 {
    var mk_pages_list = jQuery('#mk_pages_list');
    mk_pages_list.multiselect({
        listWidth: 1000
    });
    jQuery('#logged_allowed_operations').multiselect({
        listWidth: 1000
    });
    jQuery('#ban_user_ids').multiselect({
        listWidth: 1000
    });
    jQuery('#nonlogged_allowed_operations').multiselect({
        listWidth: 1000
    });
 });