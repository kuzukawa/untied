<?php

namespace ACFCustomDatabaseTables\Model\ACFFields;

class TrueFalseACFField extends ACFFieldBase {

	const TYPE = 'true_false';

}