<?php
/**
 * CSS Enqueue.
 *
 * @package Ultimate_Dashboard_PRO
 */

defined( 'ABSPATH' ) || die( "Can't access directly" );

return function ( $module ) {

	if ( $module->screen()->is_new_admin_page() || $module->screen()->is_edit_admin_page() ) {

		//

	} elseif ( $module->screen()->is_admin_page_list() ) {

		//

	}

};
