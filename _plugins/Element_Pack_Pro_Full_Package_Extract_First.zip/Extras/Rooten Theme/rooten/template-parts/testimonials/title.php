<div class="bdt-margin-remove-bottom bdt-display-inline-block bdt-h4"><?php the_title(); ?></div>
	