<?php

namespace ACFCustomDatabaseTables\Model\ACFFields;

class DatePickerACFField extends ACFFieldBase {

	const TYPE = 'date_picker';

}