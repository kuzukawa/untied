<?php

namespace ACFCustomDatabaseTables\Model\ACFFields;

class EmailACFField extends ACFFieldBase {

	const TYPE = 'email';

}