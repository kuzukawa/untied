<?php

namespace ACFCustomDatabaseTables\Model\ACFFields;

class FlexibleContentACFField extends ACFFieldBase {

	const TYPE = 'flexible_content';
	protected $is_supported = false;
	protected $is_supported__filterable = false;

}